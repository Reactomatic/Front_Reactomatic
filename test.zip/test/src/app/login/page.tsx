import Image from "next/image";
import {Login} from "@/components/component/login";

export default function LoginPage() {
  return (
      <div>
        <Login />
      </div>

  );
}
