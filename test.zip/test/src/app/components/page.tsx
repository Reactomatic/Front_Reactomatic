import Image from "next/image";
import {ComponentList} from "@/components/component/component-list";

export default function ComponentPage() {
  return (
      <div>
        <ComponentList />
      </div>

  );
}
