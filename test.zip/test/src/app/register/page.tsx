import Image from "next/image";
import {Register} from "@/components/component/register";

export default function LoginPage() {
  return (
      <div>
        <Register />
      </div>
  );
}
