import Image from "next/image";
import {Home} from "@/components/component/home";

export default function HomePage() {
  return (
      <div>
        <Home />
      </div>

  );
}
